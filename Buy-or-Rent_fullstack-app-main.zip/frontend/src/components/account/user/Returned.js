const Bought = () => {

    return (
      <div className="userContainer">
        <p>btutaj dac bookView i poszerzyć komponent o dane kiedy została kupiona </p>
  
      </div>
    )
  }
  
  export default Bought;