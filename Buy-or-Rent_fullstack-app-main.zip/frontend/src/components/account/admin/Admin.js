const Admin  = () => {
  return (
    <div>adsd</div>
  )
}

export default Admin;
